package Universidad;

public class ProfesorUniversitario {
}
