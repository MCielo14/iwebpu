package Universidad;

public class Estudiante {
    public String nombre;
    public String edad;
    public String codigo;
    public float craest = 50f;
    public int x;

    public String decirMiNombre() {
        return nombre;
    }
    
    public void decirNombre(){
        System.out.println(nombre);
    }

    public int sumar(int x, int y) {
        return x + y;
    }

    public int sumar2(int x) {
        return this.x + x;
    }
}
