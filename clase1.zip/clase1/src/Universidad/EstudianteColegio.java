package Universidad;

public class EstudianteColegio {
}
