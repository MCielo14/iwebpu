package hi;

public class Profesor {
}
