import Universidad.Estudiante;

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello world!");

        System.out.print("hola mundo");

        System.out.println("holaaaaaa");

        String nombre = "Stuardo";
        String asd;
        asd = "Cesar";

        int x = 5;
        boolean y = false;
        float w = 5.6f;
        double q = 5.6d;

        int suma = 5 + 6;
        suma++;
        ++suma;

        System.out.println(suma++);
        System.out.println(++suma);
        System.out.println("suma: " + suma);
        System.out.println("suma: " + (5 + 6 + 8 + 9));

        int resta = 5 - 6;


        float div = 5 / (2*1f);



        System.out.println("div: " + div);

        Estudiante estudiante = new Estudiante();
        estudiante.nombre = "Leonard";
        //estudiante.x=9;/

        Estudiante e3 = estudiante;

        Estudiante e2 = new Estudiante();
        e2.nombre = "Ricardo";

        System.out.println("nombre: " + estudiante.nombre);
        System.out.println("nombre: " + estudiante.decirMiNombre());
        System.out.println("nombre: " + estudiante.sumar2(20));
        int xx = 5;

        System.out.println(e2.sumar(6,7));

        e2.x = 50;
        System.out.println(e2.sumar2(10));

        e2.x = 80;
        System.out.println(e2.sumar2(10));
        estudiante.craest = 60;
        e2.craest = 40;
        
    }
}