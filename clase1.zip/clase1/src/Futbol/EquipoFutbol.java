package Futbol;

public class EquipoFutbol {
}
